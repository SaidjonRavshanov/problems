#include <iostream>
using namespace std;
int main(){
//1. Qiymati [-999; 999] oraliqda yotuvchi butun son berilgan. Son qiymatiga mos ravishda 
//�uch xonali manfiy�, 
//�ikki xonali manfiy�, 
//�bir xonali manfiy�, 
//�nol soni�, 
//�bir xonali musbat son�, 
//�ikki xonali musbat son�,
//�uch xonali musbat son� 
//kabi satrlarni ekranga chiqaruvchi dastur tuzilsin.
//
//int a;
//cin>>a;
//if(a>0 && a<=9){
//	cout<<"bir xonali musbat \n";
//} else if (a>=10 && a<=99){
//	cout<<"ikki xonali musbat \n";
//} else if(a>=100 && a<=999){
//	cout<<"uch xonali musbat \n";
//} else if(a>=-9 && a<0){
//	cout<<"bir xonali manfiy \n";
//} else if (a<=-10 && a>=-99){
//	cout<<"ikki xonali manfiy \n";
//} else if(a<=-100 && a>=-999){
//	cout<<"uch xonali manfiy \n";
//} else if(a==0) {cout<<"nol soni \n";
//}

//2. Qiymati [1; 9999] bo�lgan x butun soni berilgan. Bu sonning  qiymatiga mos ravishda quyidagi satrlarni chop eting: 
//�to�rt xonali juft son�, 
//�to�rt xonali toq son�, 
//�uch xonali juft son�, 
//�uch xonali toq son�, 
//�ikki xonali juft son�, 
//�ikki xonali toq son�, 
//�bir xonali juft son�, 
//�bir xonali toq son�, 
//va � ekranga chiqaruvchi dastur tuzilsin.
int x;
cin>>x;
if(x>0){

if(x%2==0){
	cout << ((x >= 1 && x <= 9) ? "1 xonali juft son" :
                (x >= 10 && x <= 99) ? "2 xonali juft son" :
                (x >= 100 && x <= 999) ? "3 xonali juft son" :
                (x >= 1000 && x <= 9999) ? "4 xonali juft son" :
                "oshib ketdi") << endl;
	} else cout<< ((x >= 1 && x <= 9) ? "1 xonali toq son" :
                (x >= 10 && x <= 99) ? "2 xonali toq son" :
                (x >= 100 && x <= 999) ? "3 xonali toq son" :
                (x >= 1000 && x <= 9999) ? "4 xonali toq son" :
                "oshib ketdi ") << endl;




}
	main();
	
	return 0;
}
